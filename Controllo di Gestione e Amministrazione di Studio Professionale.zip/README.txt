Istruzioni necessarie per l'utilizzo e il test del software:

1. Importare l'archivio 'Controllo2016.zip' all'interno di un programma di sviluppo software (es. Eclipse).
2. Creare il dataset associato utilizzando il file 'Tesi_2016.sql', eseguendolo all'interno di un programma di amministrazione di database (Mysql, HeidiSql, ...).
3. Configurare la connessione al dataset nella classe DbHelper, package 'utility', nella funzione init().
4. Lanciare l'applicazione all'interno del programma di sviluppo software, eseguire la classe Main che si trove nel package 'controllo2016.start'.   